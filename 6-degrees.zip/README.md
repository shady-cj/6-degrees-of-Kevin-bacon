# Prerequisite

python3
upgrade pip using
`python -m pip install --upgrade pip`

Install required packages
`pip install -r requirements.txt`



# USAGE

Run
`python main.py`

* You get a prompt that asks for actors name
* This gets the bacons number using graph algorithm's bfs
* The prompt continues to re-prompt
* To quit out of it you should type `return` and enter


